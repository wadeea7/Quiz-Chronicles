import java.io.*;
import java.util.*;

public class QuizGameApp {
    // Scanner for taking user input
    static Scanner sc = new Scanner(System.in);

    // Lists to store user data and quiz records
    static ArrayList<String[]> users = new ArrayList<>();
    static ArrayList<String[]> records = new ArrayList<>();

    public static void main(String[] args) {
        loadUsers();     // Load existing users from file
        loadRecords();   // Load existing records from file
        welcomeScreen(); // Show main menu
        saveUsers();     // Save any changes to users
        saveRecords();   // Save any new records
    }

    // Show the first menu the user sees
    static void welcomeScreen() {
        System.out.println("=======================================");
        System.out.println("     WELCOME TO THE QUIZ CHRONICLES    ");
        System.out.println("=======================================");
        while (true) {
            System.out.println("\n1. Login");
            System.out.println("2. Register (New Player)");
            System.out.println("0. Exit");

            String choice = readChoice(new String[]{"0", "1", "2"}, "Enter choice: ");
            if (choice.equals("1")) login();
            else if (choice.equals("2")) register();
            else {
                System.out.println("Thank you for playing!");
                return;
            }
        }
    }

    // Register a new user
    static void register() {
        String username;
        while (true) {
            System.out.print("Enter Username: ");
            username = sc.nextLine().trim();
            if (username.isEmpty()) {
                System.out.println("Username cannot be empty.");
                continue;
            }
            boolean exists = false;
            for (String[] user : users) {
                if (user.length >= 1 && user[0].equals(username)) {
                    exists = true;
                    break;
                }
            }
            if (exists) {
                System.out.println("Username already taken. Try another.");
            } else break;
        }

        String password;
        while (true) {
            System.out.print("Enter Password: ");
            password = sc.nextLine().trim();
            if (password.isEmpty()) {
                System.out.println("Password cannot be empty.");
            } else break;
        }

        // Get age and check if user is allowed
        int age = 0;
        try {
            System.out.print("Enter age (13-50): ");
            age = manualParseInt(sc.nextLine());
            if (age < 13 || age > 50) {
                System.out.println("Sorry, this quiz game is only for users aged between 13 and 50.");
                System.out.println("Thank you for your interest. Goodbye!");
                return;
            }
        } catch (Exception e) {
            System.out.println("Invalid input. Age must be a number between 13 and 50.");
            System.out.println("Terminating registration process. Goodbye!");
            return;
        }

        users.add(new String[]{username, password, String.valueOf(age), "Player"});
        saveUsers();
        System.out.println("Registration successful!");
    }

    // Log in existing users
    static void login() {
        String username, password;

        while (true) {
            System.out.print("Username: ");
            username = sc.nextLine().trim();
            if (username.isEmpty()) {
                System.out.println("Username cannot be empty.");
            } else break;
        }

        while (true) {
            System.out.print("Password: ");
            password = sc.nextLine().trim();
            if (password.isEmpty()) {
                System.out.println("Password cannot be empty.");
            } else break;
        }

        for (String[] user : users) {
            if (user.length >= 3 && user[0].equals(username) && user[1].equals(password)) {
                playerMenu(username, user[2]); // Logged in
                return;
            }
        }
        System.out.println("Login failed. Check credentials.");
    }

    // Player main menu
    static void playerMenu(String username, String age) {
        while (true) {
            System.out.println("\n--- Player Menu ---");
            System.out.println("1. Start Quiz");
            System.out.println("2. View My Records");
            System.out.println("3. View Leaderboard");
            System.out.println("0. Logout");

            String choice = readChoice(new String[]{"0", "1", "2", "3"}, "Enter choice: ");
            if (choice.equals("1")) startPlayerQuiz(username, age);
            else if (choice.equals("2")) viewMyRecords(username);
            else if (choice.equals("3")) viewLeaderboard();
            else return;
        }
    }

    // Start a quiz for a player
    static void startPlayerQuiz(String username, String age) {
        String difficulty;
        while (true) {
            System.out.print("Select difficulty (Easy / Medium / Hard): ");
            difficulty = sc.nextLine().toLowerCase();
            if (difficulty.equals("easy") || difficulty.equals("medium") || difficulty.equals("hard")) break;
            else System.out.println("Invalid difficulty. Try again.");
        }

        String category = "";
        System.out.println("Select category:");
        System.out.println("1. General\n2. Computer\n3. Science\n4. Geography\n5. History\n6. Sports");

        String catChoice = readChoice(new String[]{"1", "2", "3", "4", "5", "6"}, "Enter category number: ");
        switch (catChoice) {
            case "1": category = "general"; break;
            case "2": category = "computer"; break;
            case "3": category = "science"; break;
            case "4": category = "geography"; break;
            case "5": category = "history"; break;
            case "6": category = "sports"; break;
        }

        // Load questions for selected difficulty and category
        ArrayList<String[]> questions = loadQuestions(difficulty, category);
        if (questions.isEmpty()) {
            System.out.println("No questions found for selected difficulty/category.");
            return;
        }

        int score = startQuiz(questions); // Start quiz
        System.out.println("\nYour Score: " + score + "/" + questions.size());

        // Feedback based on score
        if (score == questions.size()) System.out.println("Perfect Score! Well done.");
        else if (score >= questions.size() * 0.7) System.out.println("Great job!");
        else if (score >= questions.size() * 0.4) System.out.println("Good try. Keep improving.");
        else System.out.println("Needs more practice. Don't give up!");

        // Save score
        records.add(new String[]{username, age, String.valueOf(score), difficulty, category});
        saveRecords();

        // Ask to view leaderboard
        System.out.print("\nWould you like to see the Leaderboard? (yes/no): ");
        String view = readChoice(new String[]{"yes", "no"}, "");
        if (view.equalsIgnoreCase("yes")) viewLeaderboard();
    }

    // Load questions from file based on difficulty and category
    static ArrayList<String[]> loadQuestions(String level, String category) {
        ArrayList<String[]> list = new ArrayList<>();
        String fileName = level + "_" + category + ".txt";
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = manualSplit(line, '~');
                if (parts.length == 6) list.add(parts);
            }
        } catch (IOException e) {
            System.out.println("Error loading questions from " + fileName);
        }
        return list;
    }

    // Ask each question and check answers
    static int startQuiz(ArrayList<String[]> questions) {
        int score = 0;
        long startTime = System.currentTimeMillis();
        customShuffle(questions);

        for (String[] q : questions) {
            System.out.println("\n" + q[0]);
            System.out.println("a) " + q[1]);
            System.out.println("b) " + q[2]);
            System.out.println("c) " + q[3]);
            System.out.println("d) " + q[4]);

            String ans = readChoice(new String[]{"a", "b", "c", "d"}, "Answer (a/b/c/d): ");
            if (ans.equals(q[5])) score++;
        }

        long endTime = System.currentTimeMillis();
        long timeTaken = (endTime - startTime) / 1000;
        System.out.println("Time Taken: " + (timeTaken / 60) + " min " + (timeTaken % 60) + " sec");

        return score;
    }

    // Show top 5 scores
    static void viewLeaderboard() {
        System.out.println("\n--- Leaderboard ---");

        // Sort records by score descending
        for (int i = 0; i < records.size() - 1; i++) {
            for (int j = i + 1; j < records.size(); j++) {
                if (records.get(i).length < 3 || records.get(j).length < 3) continue;
                int score1 = manualParseInt(records.get(i)[2]);
                int score2 = manualParseInt(records.get(j)[2]);
                if (score2 > score1) {
                    String[] temp = records.get(i);
                    records.set(i, records.get(j));
                    records.set(j, temp);
                }
            }
        }

        for (int i = 0; i < Math.min(5, records.size()); i++) {
            String[] r = records.get(i);
            if (r.length >= 5) {
                System.out.println((i + 1) + ". " + r[0] + " - Score: " + r[2] + ", Level: " + r[3] + ", Category: " + r[4]);
            }
        }
    }

    // Show current user's quiz attempts
    static void viewMyRecords(String username) {
        System.out.println("\n--- My Records ---");
        boolean found = false;
        for (String[] r : records) {
            if (r.length >= 5 && r[0].equals(username)) {
                System.out.println("Score: " + r[2] + ", Level: " + r[3] + ", Category: " + r[4]);
                found = true;
            }
        }
        if (!found) System.out.println("No records found.");
    }

    // Load user data from file
    static void loadUsers() {
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = manualSplit(line, ',');
                if (parts.length >= 3) users.add(parts);
            }
        } catch (IOException e) {
            System.out.println("Could not load users.txt. Starting with empty user list.");
        }
    }

    // Save users to file
    static void saveUsers() {
        try (PrintWriter pw = new PrintWriter("users.txt")) {
            for (String[] u : users) {
                pw.println(String.join(",", u));
            }
        } catch (IOException ignored) {}
    }

    // Load previous records
    static void loadRecords() {
        try (BufferedReader br = new BufferedReader(new FileReader("records.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = manualSplit(line, ',');
                if (parts.length >= 5) records.add(parts);
            }
        } catch (IOException e) {
            System.out.println("Could not load records.txt. Starting with empty records.");
        }
    }

    // Save records to file
    static void saveRecords() {
        try (PrintWriter pw = new PrintWriter("records.txt")) {
            for (String[] r : records) {
                pw.println(String.join(",", r));
            }
        } catch (IOException ignored) {}
    }

    // Split a line of text by a specific character
    static String[] manualSplit(String line, char delimiter) {
        ArrayList<String> parts = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        for (char ch : line.toCharArray()) {
            if (ch == delimiter) {
                parts.add(sb.toString());
                sb.setLength(0);
            } else {
                sb.append(ch);
            }
        }
        parts.add(sb.toString());
        return parts.toArray(new String[0]);
    }

    // Convert string to integer manually
    static int manualParseInt(String input) {
        int result = 0;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= '0' && c <= '9') {
                result = result * 10 + (c - '0');
            } else {
                throw new NumberFormatException();
            }
        }
        return result;
    }

    // Shuffle list manually (like random order)
    static void customShuffle(ArrayList<String[]> list) {
        Random rand = new Random();
        for (int i = list.size() - 1; i > 0; i--) {
            int j = rand.nextInt(i + 1);
            String[] temp = list.get(i);
            list.set(i, list.get(j));
            list.set(j, temp);
        }
    }

    // Read user input and make sure it's a valid option
    static String readChoice(String[] validOptions, String prompt) {
        while (true) {
            if (!prompt.equals("")) System.out.print(prompt);
            String input = sc.nextLine().toLowerCase();
            for (String option : validOptions) {
                if (input.equals(option)) return input;
            }
            System.out.println("Invalid input. Try again.");
        }
    }
}